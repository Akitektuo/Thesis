public class MoneyTransfer {
    public static void main(String[] args) {
        var bankAccountAlex = new BankAccount("Alex", 2000);
        var bankAccountDad = new BankAccount("Dad", 3000);
        var bankAccountMom = new BankAccount("Mom", 4000);

        transferMoney(bankAccountDad, bankAccountAlex, 500);
        transferMoney(bankAccountMom, bankAccountAlex, 500);
        transferMoney(bankAccountMom, bankAccountDad, 500);
        transferMoney(bankAccountDad, bankAccountMom, 100);
        transferMoney(bankAccountAlex, bankAccountAlex, 300);
        transferMoney(bankAccountAlex, bankAccountMom, 200);

        System.out.println(bankAccountAlex);
        System.out.println(bankAccountDad);
        System.out.println(bankAccountMom);
    }

    // TODO: Add method
}
