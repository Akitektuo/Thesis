public class MoneyTransfer {
    public static void main(String[] args) {
        var bankAccountAlex = new BankAccount("Alex", 2000);
        var bankAccountDad = new BankAccount("Dad", 3000);
        var bankAccountMom = new BankAccount("Mom", 4000);

        bankAccountDad.transferTo(bankAccountAlex, 500);
        bankAccountMom.transferTo(bankAccountAlex, 500);
        bankAccountMom.transferTo(bankAccountDad, 500);
        bankAccountDad.deposit(200);
        bankAccountDad.transferTo(bankAccountMom, 100);
        bankAccountAlex.transferTo(bankAccountAlex, 300);
        bankAccountAlex.transferTo(bankAccountMom, 200);
        bankAccountAlex.withdraw(90);

        System.out.println(bankAccountAlex);
        System.out.println(bankAccountDad);
        System.out.println(bankAccountMom);
    }
}
