// TODO: Create class and create member methods
