import java.util.ArrayList;
import java.util.Arrays;

public class MoneyTransfer {
    public static void main(String[] args) {
        var accountBalances = new ArrayList<>(Arrays.asList(2000, 3000, 4000));

        transferMoney(accountBalances, 1, 0, 500);
        transferMoney(accountBalances, 2, 0, 500);
        transferMoney(accountBalances, 2, 1, 500);
        transferMoney(accountBalances, 1, 2, 100);
        transferMoney(accountBalances, 0, 1, 300);
        transferMoney(accountBalances, 0, 2, 200);

        System.out.println(accountBalances);
    }

    // TODO: Add method
}
